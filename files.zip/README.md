# SEL Activity Library - Deployment Guide

## 🚀 Quick Deploy to GitHub Pages

### Step 1: Create GitHub Account & Repository
1. Go to [github.com](https://github.com) and sign up (free)
2. Click the **"+"** in top right → **"New repository"**
3. Name it: `sel-activity-library`
4. Make it **Public**
5. Click **"Create repository"**

### Step 2: Upload Your File
1. On your new repository page, click **"uploading an existing file"**
2. Drag and drop `index.html` (rename the file you downloaded to `index.html`)
3. Scroll down and click **"Commit changes"**

### Step 3: Enable GitHub Pages
1. In your repository, click **"Settings"** (top menu)
2. Scroll down to **"Pages"** in the left sidebar
3. Under "Source", select **"main"** branch
4. Click **"Save"**
5. Wait 1-2 minutes, then refresh the page
6. You'll see: **"Your site is published at https://YOUR-USERNAME.github.io/sel-activity-library/"**

**That's it! Your site is live! 🎉**

---

## 📝 Editing with VSCode + Claude

### Option 1: Edit Directly on GitHub
1. Click the `index.html` file in your repository
2. Click the pencil icon (✏️) to edit
3. Make changes
4. Scroll down, click "Commit changes"
5. Your site updates automatically!

### Option 2: Edit Locally with VSCode
1. **Download VSCode**: [code.visualstudio.com](https://code.visualstudio.com)
2. **Clone your repository**:
   - In VSCode, press `Ctrl+Shift+P` (or `Cmd+Shift+P` on Mac)
   - Type "Git: Clone" and press Enter
   - Paste: `https://github.com/YOUR-USERNAME/sel-activity-library.git`
   - Choose where to save it

3. **Make edits**:
   - Open `index.html` in VSCode
   - Edit the file
   - Save (`Ctrl+S` or `Cmd+S`)

4. **Push changes back to GitHub**:
   - In VSCode, click the Source Control icon (left sidebar)
   - Type a message like "Updated activities"
   - Click the checkmark ✓ to commit
   - Click the ••• menu → "Push"

5. **Your site updates automatically!**

---

## 🤖 Using Claude Agent in VSCode

1. **Install Claude Extension**:
   - In VSCode, click Extensions icon (left sidebar)
   - Search for "Claude"
   - Install the official Claude extension

2. **Chat with Claude**:
   - Press `Ctrl+L` (or `Cmd+L` on Mac) to open Claude
   - Ask Claude to help you edit the file
   - Example: "Add a new activity about mindfulness for 2nd graders"
   - Claude will suggest code changes you can accept!

---

## 📂 File Structure

```
sel-activity-library/
├── index.html          # Your main website file
└── README.md           # This file
```

---

## 🎨 Customization Ideas

Ask Claude (in VSCode or claude.ai) to help you:
- Change the colors/theme
- Add more activities
- Modify the filtering options
- Add images or icons
- Create printable versions
- Add a search feature
- Embed videos

---

## 🔧 Troubleshooting

**Site not showing up?**
- Wait 2-3 minutes after enabling GitHub Pages
- Make sure file is named `index.html` (not `index.htm` or anything else)
- Check Settings → Pages shows "Your site is published"

**Changes not showing?**
- GitHub Pages can take 1-2 minutes to update
- Try hard refresh: `Ctrl+Shift+R` (or `Cmd+Shift+R` on Mac)
- Clear your browser cache

**Need help?**
- Ask Claude at [claude.ai](https://claude.ai)
- GitHub has great [documentation](https://docs.github.com/en/pages)

---

## 📊 What You Have

✅ 32 SEL activities for ages 3-8 (K-3rd grade)
✅ Filterable by grade, type, and specific skills
✅ Self-Awareness focused activities
✅ Mobile-responsive design
✅ Completely free hosting on GitHub Pages
✅ Easy to edit and expand

---

## 🎯 Next Steps

1. **Add more content**: Fetch and embed full activity details
2. **Add Self-Management activities**: Upload the second CSV
3. **Customize styling**: Change colors to match your brand
4. **Add analytics**: Track which activities are most popular
5. **Share it**: Give parents the link!

---

## 💡 Tips

- **Bookmark your live URL** so you can easily share it
- **Star your GitHub repo** to find it easily later
- **Make regular backups** by downloading the file periodically
- **Test on mobile** to ensure it looks good on phones/tablets

---

## 🆘 Need Help?

Just ask Claude! Copy this template:

```
I'm working on my SEL Activity Library deployed at GitHub Pages.
I want to [describe what you want to do].
Can you help me modify the HTML file?
```

Happy building! 🎉
